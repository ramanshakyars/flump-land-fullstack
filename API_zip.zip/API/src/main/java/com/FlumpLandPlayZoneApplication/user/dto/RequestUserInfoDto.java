package com.FlumpLandPlayZoneApplication.user.dto;


import lombok.Data;
import java.util.Date;

@Data
public class RequestUserInfoDto {
    private String fullName;
    private Date dateOfJoining;
    private Date dateOfBirth;
    private String mothersName;
    private String fatherName;
    private String parentContactNo;
    private String contactNumber;
    private String address;
}
